If this is a question or feature request, make sure to:

- [ ] The title starts with `Question:` or `Feature:`.

If this is an bug report, not a question, make sure to:

- [ ] I'm not running Windows (which is unsupported), or if I am, I can confirm this issue appears on another platform, or Vagrant.
- [ ] This issue appears in the latest `dev` branch.
- [ ] I've included my browser and Ruby version in this issue.
